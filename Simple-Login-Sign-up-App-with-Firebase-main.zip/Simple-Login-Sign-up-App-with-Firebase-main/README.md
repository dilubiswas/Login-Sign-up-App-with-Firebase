# Simple-Login-Sign-up-App-with-Firebase

# Output
![WhatsApp Image 2022-11-28 at 11 56 59 PM](https://user-images.githubusercontent.com/109650374/204886413-7553c698-e640-426d-b621-374d248f37ca.jpeg) ![WhatsApp Image 2022-11-28 at 11 56 59 PM (1)](https://user-images.githubusercontent.com/109650374/204886437-2d56e5a9-f097-4865-82cf-3585296d87f5.jpeg)
![WhatsApp Image 2022-11-28 at 11 57 00 PM](https://user-images.githubusercontent.com/109650374/204886446-2ebbc75f-1994-44bd-ab0b-c7190903a225.jpeg) ![WhatsApp Image 2022-11-28 at 11 57 00 PM (1)](https://user-images.githubusercontent.com/109650374/204886457-c1b71c42-9137-4ddb-9e28-f493c91c3d66.jpeg)
